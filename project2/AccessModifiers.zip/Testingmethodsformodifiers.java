package project2;
public class Testingmethodsformodifiers {
public static void main(String [] args) {
		
		AccessModifiers obj= new  AccessModifiers();
				
				obj.methodDefault();
			//obj.methodPrivate(); private method we can't access out side of class, its scope is within the class
				obj.methodProtected();
				obj.methodPublic();
			}

}
