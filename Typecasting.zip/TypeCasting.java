package project1;

public class TypeCasting {
	public static void main(String [] args) {
		
         //IMPLICIT
		System.out.println("implicit typecasting: ");
		byte a=10;
		System.out.println("Byte: "+a);

		short b=a;
		System.out.println("Byte to Short Conversion: "+b);

		int c =b;
		System.out.println("Short to Int Conversion: "+c);

		int d=a;
		System.out.println("Byte to Int Conversion: "+d);

		float e=d;
		System.out.println("Int to Float Conversion: "+e);

		double f=e;
		System.out.println("Float to double Conversion: "+f);

		double g=d;
		System.out.println("Int to double Conversion: "+g);
		System.out.println("\n");
		System.out.println("explicit typecasting: ");
		//EXPLICIT
		double x=23.67;
		int y=(int)x;
		System.out.println("converted double " +x+ " to int " +y);
		

	}
}
