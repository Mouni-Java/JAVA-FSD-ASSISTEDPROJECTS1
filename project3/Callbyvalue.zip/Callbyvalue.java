package project3;
public class Callbyvalue {
		int num=50;
		void operation(int num) {
			this.num=num*10/100;
		}
		public static void main(String[] args) {
			Callbyvalue obj=new Callbyvalue();
			System.out.println("value of num before funcion call:"+obj.num);
		obj.operation(100);
		System.out.println("value of num after fun call:"+obj.num);
		
		}

	}



