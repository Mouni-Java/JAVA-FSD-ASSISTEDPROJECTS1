package project4;
public class EmploYee {
	int empId;
	String empName;
	String department;
	float salary;
	public EmploYee() {
		empId=1;
		empName="Emp001";
		department="Finance";
		salary=35000;
	}
public EmploYee(int empId,String empName,String department,float salary) {
	this.empId=empId;
	this.empName=empName;
	this.department=department;
	this.salary=salary;
}
public void display() {
	System.out.println("ID:"+empId);
	System.out.println("name:"+empName);;
	System.out.println("department:"+department);
	System.out.println("salary:"+salary);
}
public static void main(String[] args) {
	
	EmploYee e= new EmploYee();
	EmploYee e1= new EmploYee(12, "Nikunj Soni", "Training", 450000); 

	//calling default constructor
	e.display();
	//parametrized constructor
	e1.display();
}
	

}



